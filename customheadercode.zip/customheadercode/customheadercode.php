<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class CustomHeaderCode extends Module
{
    public function __construct()
    {
        $this->name = 'customheadercode';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Julien Chrétien';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Custom Header Code');
        $this->description = $this->l('Permet d\'injecter du code personnalisé dans le header. Créé par Julien Chrétien - https://julienchretien.com');

        $this->confirmUninstall = $this->l('Êtes-vous sûr de vouloir désinstaller ce module ?');
    }

    public function install()
    {
        return parent::install() && $this->registerHook('header') && $this->installTab();
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->unregisterHook('header') && $this->uninstallTab();
    }

    private function installTab()
    {
        $tab = new Tab();
        $tab->class_name = 'AdminCustomHeaderCode';
        $tab->id_parent = (int) Tab::getIdFromClassName('AdminParentModulesSf');
        $tab->module = $this->name;
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Custom Header Code';
        }
        return $tab->add();
    }

    private function uninstallTab()
    {
        $id_tab = (int) Tab::getIdFromClassName('AdminCustomHeaderCode');
        $tab = new Tab($id_tab);
        return $tab->delete();
    }

    public function hookHeader($params)
    {
        $custom_code = Configuration::get('CUSTOM_HEADER_CODE');
        if ($custom_code) {
            // Encapsuler le code avec <script> pour s'assurer qu'il s'injecte correctement
            return '<script type="text/javascript">' . $custom_code . '</script>';
        }
        return '';
    }

    public function getContent()
    {
        $output = '';
        if (Tools::isSubmit('submit' . $this->name)) {
            $custom_code = Tools::getValue('CUSTOM_HEADER_CODE');
            Configuration::updateValue('CUSTOM_HEADER_CODE', $custom_code);
            $output .= $this->displayConfirmation($this->l('Configuration mise à jour'));
        }
        return $output . $this->renderForm();
    }

    protected function renderForm()
    {
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submit' . $this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Custom Header Code Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'textarea',
                        'label' => $this->l('Code to inject in header'),
                        'name' => 'CUSTOM_HEADER_CODE',
                        'cols' => 40,
                        'rows' => 10,
                        'desc' => $this->l('Add your custom code that will be injected into the header of your site.'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    protected function getConfigFormValues()
    {
        return array(
            'CUSTOM_HEADER_CODE' => Configuration::get('CUSTOM_HEADER_CODE', ''),
        );
    }
}
